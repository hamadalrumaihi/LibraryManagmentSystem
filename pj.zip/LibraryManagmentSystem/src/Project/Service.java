package Project;

public class Service {
	private boolean printing, proofReading;
	private double printintgCostPerPage, proofReadingCostPerPage;

	public boolean isPrinting() {
		return printing;
	}

	public void setPrinting(boolean printing) {
		this.printing = printing;
	}

	public boolean isProofReading() {
		return proofReading;
	}

	public void setProofReading(boolean proofReading) {
		this.proofReading = proofReading;
	}

	public double getPrintintgCostPerPage() {
		return printintgCostPerPage;
	}

	public void setPrintintgCostPerPage(double printintgCostPerPage) {
		this.printintgCostPerPage = printintgCostPerPage;
	}

	public double getProofReadingCostPerPage() {
		return proofReadingCostPerPage;
	}

	public void setProofReadingCostPerPage(double proofReadingCostPerPage) {
		this.proofReadingCostPerPage = proofReadingCostPerPage;
	}

	public Service(boolean printing, boolean proofReading, double printintgCostPerPage,
			double proofReadingCostPerPage) {
		super();
		this.printing = printing;
		this.proofReading = proofReading;
		this.printintgCostPerPage = printintgCostPerPage;
		this.proofReadingCostPerPage = proofReadingCostPerPage;
	}

	@Override
	public String toString() {
		return "Service [printing=" + printing + ", proofReading=" + proofReading + ", printintgCostPerPage="
				+ printintgCostPerPage + ", proofReadingCostPerPage=" + proofReadingCostPerPage + "]";
	}
}