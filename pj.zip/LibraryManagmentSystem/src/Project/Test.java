package Project;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Test implements Serializable {

	private static final long serialVersionUID = 1L;

	private Application app = loadData("app.dat");

	public void saveData(String txtFile) {
		try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(txtFile))) {
			outputStream.writeObject(app);
			System.out.println("application data saved successfully.");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public Application loadData(String txtfile) {
		Application app = new Application();
		try (ObjectInputStream transInObj = new ObjectInputStream(new FileInputStream(txtfile))) {
			Object obj = transInObj.readObject();
			app = (Application) obj;
			System.out.println("application data loaded successfully.");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return app;

	}

	public void addNewItem() {
		try {
			Scanner option = new Scanner(System.in);
			System.out.println("Add New Item:");
			System.out.println("1- Book");
			System.out.println("2- Scientific Journal");
			System.out.println("3- Magazine");
			System.out.println("4- News Paper");
			System.out.print("Choose the type of item to add (1-4): ");
			int itemType = option.nextInt();
			if (itemType >= 1 && itemType <= 4) {
				switch (itemType) {
				case 1:
					addNewBook();
					break;
				case 2:
					addNewScientificJournal();
					break;
				case 3:
					addNewMagazine();
					break;
				case 4:
					addNewNewspaper();
					break;
				}
			} else {
				System.out.println("Invalid option. Please choose a number between 1 and 4.");
			}
		} catch (Exception e) {
			System.out.println("Invalid input. Please enter a number.");
		}
	}

	public void addNewBook() {
		Scanner bookIn = new Scanner(System.in);
		System.out.println("Adding a New Book:");

		System.out.print("Enter ISBN: ");
		String isbn = bookIn.next();

		System.out.print("Enter item ID: ");
		int itemId = bookIn.nextInt();
		bookIn.nextLine();
		System.out.print("Enter genre: ");
		String genre = bookIn.nextLine();

		System.out.print("Enter description: ");
		String description = bookIn.nextLine();

		System.out.print("Enter number of pages: ");
		int pages = bookIn.nextInt();

		System.out.print("Enter  Days by which the book is due for return : ");
		int dueDays = bookIn.nextInt();
		bookIn.nextLine();
		System.out.print("Enter title: ");
		String title = bookIn.nextLine();
		// author input
		System.out.print("Enter First name of the author: ");
		String firstName = bookIn.nextLine();
		System.out.print("Enter last name of the author: ");
		String lastName = bookIn.nextLine();
		System.out.print("Enter date Of Birth: ");
		System.out.println("--------");
		System.out.print("Enter day: ");
		int day = bookIn.nextInt();
		System.out.print("Enter month: ");
		int month = bookIn.nextInt();
		System.out.print("Enter year: ");
		int year = bookIn.nextInt();
		LocalDate dateOfBirth = LocalDate.of(year, month, day);
		Author author = new Author(firstName, lastName, dateOfBirth);
		// Publishing Date input
		System.out.print("Enter Publishing Date: " + "\n");
		System.out.println("--------");
		System.out.print("Enter day: ");
		int Pday = bookIn.nextInt();
		System.out.print("Enter month: ");
		int Pmonth = bookIn.nextInt();
		System.out.print("Enter year: ");
		int Pyear = bookIn.nextInt();
		LocalDate PublishingDate = LocalDate.of(year, month, day);
		// price input
		System.out.print("Enter the price of the book: ");
		Double price = bookIn.nextDouble();
		Book book = new Book(itemId, pages, dueDays, title, author, price, PublishingDate, isbn, genre, description);
		app.getItems().add(book);
		app.getAuthors().add(author);
		System.out.println("Book added successfully");
	}

	public void addNewScientificJournal() {
		Scanner SciIn = new Scanner(System.in);
		System.out.println("Adding a New Scientific Journal:");

		System.out.print("Enter publication frequency: ");
		String publicationFrequency = SciIn.nextLine();

		System.out.print("Enter impact factor: ");
		Double impactFactor = SciIn.nextDouble();
		System.out.print("Enter item ID: ");
		int itemId = SciIn.nextInt();
		SciIn.nextLine();
		System.out.print("Enter title: ");
		String title = SciIn.nextLine();
		System.out.print("Enter number of pages: ");
		int pages = SciIn.nextInt();
		System.out.print("Enter publishing Date: " + "\n");
		System.out.println("--------");
		System.out.println("Enter day: ");
		int pday = SciIn.nextInt();
		System.out.print("Enter month: ");
		int pmonth = SciIn.nextInt();
		System.out.print("Enter year: ");
		int pyear = SciIn.nextInt();
		LocalDate publishingDate = LocalDate.of(pyear, pmonth, pday);

		System.out.print("Enter  Days by which the journal is due for return : ");
		int dueDays = SciIn.nextInt();

		System.out.print("Enter the price of the journal: ");
		Double price = SciIn.nextDouble();
		SciIn.nextLine();
		System.out.print("Enter First name of the author: ");
		String firstName = SciIn.nextLine();
		System.out.print("Enter last name of the author: ");
		String lastName = SciIn.nextLine();
		System.out.print("Enter date Of Birth: ");
		System.out.println("--------");
		System.out.println("Enter day: ");
		int day = SciIn.nextInt();
		System.out.print("Enter month: ");
		int month = SciIn.nextInt();
		System.out.print("Enter year: ");
		int year = SciIn.nextInt();
		LocalDate dateOfBirth = LocalDate.of(year, month, day);
		Author author = new Author(firstName, lastName, dateOfBirth);

		ScientificJournals scientificJournal = new ScientificJournals(itemId, pages, dueDays, title, author, price,
				publishingDate, publicationFrequency, impactFactor);
		app.getItems().add(scientificJournal);
		app.getAuthors().add(author);
		System.out.println("Scientific Journal added successfully");
	}

	public void addNewMagazine() {
		Scanner magIn = new Scanner(System.in);
		System.out.println("Adding a New Magazine:");

		System.out.print("Enter issue number: ");
		int issueNumber = magIn.nextInt();
		System.out.print("Enter item ID: ");
		int itemId = magIn.nextInt();
		magIn.nextLine();
		System.out.print("Enter title: ");
		String title = magIn.nextLine();
		System.out.print("Enter  Days by which the Magazine is due for return : ");
		int dueDays = magIn.nextInt();
		System.out.print("Enter number of pages: ");
		int pages = magIn.nextInt();
		magIn.nextLine();
		System.out.print("Enter author's first name: ");
		String authorFirstName = magIn.nextLine();
		System.out.print("Enter author's last name: ");
		String authorLastName = magIn.nextLine();
		System.out.print("Enter date Of creation: " + "\n");
		System.out.println("--------");
		System.out.println("Enter day: ");
		int day = magIn.nextInt();
		System.out.print("Enter month: ");
		int month = magIn.nextInt();
		System.out.print("Enter year: ");
		int year = magIn.nextInt();
		LocalDate dateOfBirth = LocalDate.of(year, month, day);
		Author author = new Author(authorFirstName, authorLastName, dateOfBirth);
		System.out.print("Enter publishing Date: ");
		System.out.println("--------");
		System.out.println("Enter day: ");
		int pday = magIn.nextInt();
		System.out.print("Enter month: ");
		int pmonth = magIn.nextInt();
		System.out.print("Enter year: ");
		int pyear = magIn.nextInt();
		LocalDate publishingDate = LocalDate.of(pyear, pmonth, pday);
		System.out.print("Enter the price of the magazine: ");
		Double price = magIn.nextDouble();
		Magazines magazine = new Magazines(itemId, pages, dueDays, title, author, price, publishingDate, issueNumber);
		app.getItems().add(magazine);
		app.getAuthors().add(author);
		System.out.println("Magazine added successfully");
	}

	public void addNewNewspaper() {
		Scanner newsIn = new Scanner(System.in);
		System.out.println("Adding a New Newspaper:");
		System.out.print("Enter item ID: ");
		int itemId = newsIn.nextInt();
		System.out.print("Enter  Days by which the Newspaper is due for return : ");
		int dueDays = newsIn.nextInt();
		System.out.print("Enter number of pages: ");
		int pages = newsIn.nextInt();
		newsIn.nextLine();
		System.out.print("Enter title: ");
		String title = newsIn.nextLine();
		System.out.print("Enter author's first name: ");
		String authorFirstName = newsIn.nextLine();
		System.out.print("Enter author's last name: ");
		String authorLastName = newsIn.nextLine();
		System.out.print("Enter date Of creation : " + "\n");
		System.out.println("--------");
		System.out.println("Enter day: ");
		int day = newsIn.nextInt();
		System.out.print("Enter month: ");
		int month = newsIn.nextInt();
		System.out.print("Enter year: ");
		int year = newsIn.nextInt();
		LocalDate dateOfBirth = LocalDate.of(year, month, day);
		Author author = new Author(authorFirstName, authorLastName, dateOfBirth);
		System.out.print("Enter price: ");
		double price = newsIn.nextDouble();
		newsIn.nextLine();
		System.out.print("Enter publishing Date: ");
		System.out.println("--------");
		System.out.println("Enter day: ");
		int pday = newsIn.nextInt();
		System.out.print("Enter month: ");
		int pmonth = newsIn.nextInt();
		System.out.print("Enter year: ");
		int pyear = newsIn.nextInt();
		LocalDate publishingDate = LocalDate.of(pyear, pmonth, pday);
		newsIn.nextLine();
		System.out.print("Enter Issue Language: ");
		String issueLanguage = newsIn.nextLine();
		NewsPaper newspaper = new NewsPaper(itemId, pages, dueDays, title, author, price, publishingDate,
				issueLanguage);
		app.getItems().add(newspaper);
		app.getAuthors().add(author);

	}

	public void updateExistingItem() {
		Scanner itemUpdate = new Scanner(System.in);
		System.out.println("Update Existing Item:");
		System.out.print("Enter the title of the item to update: ");
		String searchTitle = itemUpdate.nextLine();
		Item foundItem = null;
		for (Item item : app.getItems()) {
			if (item.getTitle().toLowerCase().contains(searchTitle.toLowerCase())) {
				foundItem = item;
				break;
			}
		}
		if (foundItem == null) {
			System.out.println("Item not found.");
			return;
		}
		System.out.println("Found Item:");
		System.out.println(foundItem);
		System.out.println("Enter new details:");
		System.out.print("Enter new title: ");
		String newTitle = itemUpdate.nextLine();
		foundItem.setTitle(newTitle);
		System.out.print("Enter new author first name: ");
		String newAuthorFirstName = itemUpdate.nextLine();
		foundItem.getAuthor().setFirstName(newAuthorFirstName);
		System.out.print("Enter new author last name: ");
		String newAuthorLastName = itemUpdate.nextLine();
		foundItem.getAuthor().setLastName(newAuthorLastName);
		System.out.println("Item updated successfully.");
	}

	public void deleteExistingItem() {
		Scanner delItem = new Scanner(System.in);
		System.out.println("Delete Existing Item:");
		System.out.print("Enter the title of the item to delete: ");
		String searchTitle = delItem.nextLine();
		Item foundItem = null;
		for (Item item : app.getItems()) {
			if (item.getTitle().equalsIgnoreCase(searchTitle)) {
				foundItem = item;
				break;
			}
		}
		if (foundItem == null) {
			System.out.println("Item not found.");
			return;
		}
		app.getItems().remove(foundItem);
		System.out.println("Item deleted successfully.");
	}

	public void addNewCustomer() {
		Scanner customerInput = new Scanner(System.in);
		System.out.println("Add New Customer:");
		System.out.print("Enter customer ID: ");
		String customerId = customerInput.next().trim();

		for (Customer existingCustomer : app.getCustomers()) {
			if (existingCustomer.getCustomerId().equalsIgnoreCase(customerId)) {
				System.out.println("Customer ID already exists. Please choose a different ID.");
				return;
			}
		}
		customerInput.nextLine();
		System.out.print("Enter first name: ");
		String firstName = customerInput.nextLine().trim();
		System.out.print("Enter last name: ");
		String lastName = customerInput.nextLine().trim();
		System.out.print("Enter address: ");
		String address = customerInput.nextLine().trim();
		System.out.print("Enter phone number: ");
		String phoneNumber = customerInput.nextLine().trim();
		System.out.print("Enter  Date of birth: ");
		System.out.println("--------");
		System.out.println("Enter day: ");
		int bday = customerInput.nextInt();
		System.out.print("Enter month: ");
		int bmonth = customerInput.nextInt();
		System.out.print("Enter year: ");
		int byear = customerInput.nextInt();
		LocalDate dateOfBirth = LocalDate.of(byear, bmonth, bday);
		System.out.print("Is the customer a student? (1 for student/0 not student): ");
		int st = customerInput.nextInt();
		boolean isStudent = true;
		if (st == 0)
			isStudent = false;
		Customer newCustomer = new Customer(customerId, firstName, lastName, address, phoneNumber, dateOfBirth,
				isStudent);

		app.getCustomers().add(newCustomer);
		System.out.println("New customer added successfully.");
	}

	public void updateExistingCustomer() {
		Scanner customerInput = new Scanner(System.in);
		System.out.println("Update Existing Customer:");
		System.out.print("Enter the Customer ID to update: ");
		String searchCustomerId = customerInput.nextLine().trim();
		Customer foundCustomer = null;
		for (Customer customer : app.getCustomers()) {
			if (customer.getCustomerId().equalsIgnoreCase(searchCustomerId)) {
				foundCustomer = customer;
				break;
			}
		}
		if (foundCustomer == null) {
			System.out.println("Customer not found.");
			customerInput.close();
			return;

		}
		System.out.println("Found Customer:");
		System.out.println(foundCustomer);
		System.out.println("Enter new details:");
		System.out.print("Enter new first name: ");
		String newFirstName = customerInput.nextLine().trim();
		foundCustomer.setFirstName(newFirstName);

		System.out.print("Enter new last name: ");
		String newLastName = customerInput.nextLine().trim();
		foundCustomer.setLastName(newLastName);
		System.out.print("Enter new address: ");
		String newAddress = customerInput.nextLine().trim();
		foundCustomer.setAddress(newAddress);
		System.out.print("Enter new phone number: ");
		String newPhoneNumber = customerInput.nextLine().trim();
		foundCustomer.setPhoneNumber(newPhoneNumber);
		System.out.print("Enter  Date of birth: ");
		System.out.println("--------");
		System.out.println("Enter day: ");
		int bday = customerInput.nextInt();
		System.out.print("Enter month: ");
		int bmonth = customerInput.nextInt();
		System.out.print("Enter year: ");
		int byear = customerInput.nextInt();
		LocalDate newDateOfBirth = LocalDate.of(byear, bmonth, bday);
		foundCustomer.setDateOfBrith(newDateOfBirth);
		System.out.print("Is the customer a student? (1 for student/0 not for student): ");
		int st = customerInput.nextInt();
		if (st == 1)
			foundCustomer.setStudent(true);
		else
			foundCustomer.setStudent(false);
		System.out.println("Customer updated successfully.");
	}

	public void deleteExistingCustomer() {

		Scanner cin = new Scanner(System.in);

		System.out.println("Delete Existing Customer:");
		System.out.print("Enter the Customer ID to delete: ");
		String searchCustomerId = cin.nextLine();
		Customer foundCustomer = null;
		for (Customer customer : app.getCustomers()) {
			if (customer.getCustomerId().equalsIgnoreCase(searchCustomerId)) {
				foundCustomer = customer;
				break;
			}
		}

		if (foundCustomer == null) {
			System.out.println("Customer not found.");
			return;
		}

		app.getCustomers().remove(foundCustomer);
		System.out.println("Customer deleted successfully.");
	}

	public void borrowTransaction() {
		Scanner Borrowinput = new Scanner(System.in);
		System.out.print("Enter Transaction ID: ");
		String transID = Borrowinput.next();
		System.out.println("Borrow Transaction:");
		System.out.print("Enter Customer ID: ");
		String customerId = Borrowinput.next().trim();
		// Find the customer by ID
		Customer foundCustomer = findCustomerById(customerId);
		if (foundCustomer == null) {
			System.out.println("Customer not found.");
			return;
		}
		System.out.println("Customer Found:");
		System.out.println(foundCustomer);

		System.out.print("Enter Item ID: ");
		int itemId = Borrowinput.nextInt();
		// Find the customer by ID
		Item foundItem = findItemById(itemId);
		if (foundItem == null) {
			System.out.println("Item not found.");
			return;
		}
		// Display item details
		System.out.println("Item Found:");
		System.out.println(foundItem);
		System.out.println("Enter the service : (0: No ,1:printing, 2:proofReading, 3:printing and proofReading) : ");
		Service service = null;
		int serviceOption = Borrowinput.nextInt();
		if (serviceOption == 1) {
			System.out.println("Enter printintg Cost Per Page : ");
			double price = Borrowinput.nextDouble();
			service = new Service(true, false, price, 0);
		} else if (serviceOption == 2) {
			System.out.println("Enter proofReading Cost Per Page : ");
			double price = Borrowinput.nextDouble();
			service = new Service(false, true, 0, price);
		} else if (serviceOption == 2) {
			System.out.println("Enter printintg Cost Per Page : ");
			double pricePrint = Borrowinput.nextDouble();
			System.out.println("Enter proofReading Cost Per Page : ");
			double priceProof = Borrowinput.nextDouble();
			service = new Service(true, true, pricePrint, priceProof);
		}
		// Create a new transaction
		Transaction transaction = new Transaction(transID, foundCustomer, foundItem, LocalDate.now(), null, service);
		app.getTransactions().add(transaction);
		System.out.println("Borrow Transaction completed successfully.");
	}

	private Item findItemById(int itemId) {
		for (Item item : app.getItems()) {
			if (item.getId() == itemId) {
				return item;
			}
		}
		return null;
	}

	private Customer findCustomerById(String custId) {
		for (Customer cust : app.getCustomers()) {
			if (cust.getCustomerId().equals(custId)) {
				return cust;
			}
		}
		return null;
	}

	private Transaction findTransactionById(String transId) {
		for (Transaction transaction : app.getTransactions()) {
			if (transaction.getTransactionId().equals(transId)) {
				return transaction;
			}
		}
		return null;
	}

	private Author findAuthorsByLastName(String lastName) {
		for (Author a : app.getAuthors()) {
			if (a.getLastName().equals(lastName)) {
				return a;
			}
		}
		return null;
	}

	public void returnTransaction() {
		Scanner Returninput = new Scanner(System.in);
		System.out.print("Enter Customer ID: ");
		String customerId = Returninput.next().trim();
		// Find the customer by ID
		Customer foundCustomer = findCustomerById(customerId);
		if (foundCustomer == null) {
			System.out.println("Customer not found.");
			return;
		}
		System.out.println("Customer Found:");
		System.out.println(foundCustomer);
		ArrayList<Transaction> opendTransForThatCust = new ArrayList<Transaction>();
		for (Transaction transaction : app.getTransactions()) {
			if (transaction.getCustomer().equals(foundCustomer) && transaction.getCheckInDate() == null) {
				opendTransForThatCust.add(transaction);
			}
		}
		if (opendTransForThatCust.isEmpty()) {
			System.out.println("you do not have opende transaction");
		} else {
			for (int i = 0; i < opendTransForThatCust.size(); i++) {
				System.out.println("index : " + i + " -> " + opendTransForThatCust.get(i));
			}
			System.out.println("Enter the index of the transaction you want to return : ");
			int index = Returninput.nextInt();
			if (index >= 0 && index < opendTransForThatCust.size()) {
				opendTransForThatCust.get(index).setCheckInDate(LocalDate.now());
				System.out.println("item returned successfully");
			} else {
				System.out.println("Invalid index");
			}
		}
	}

	public void listNotYetReturnedItems() {
		System.out.println("Items Not Yet Returned:");
		for (Transaction transaction : app.getTransactions()) {
			if (transaction.getCheckInDate() == null) {
				Item item = transaction.getItem();
				System.out.println("Transaction ID: " + transaction.getTransactionId());
				System.out.println("Customer: " + transaction.getCustomer().getFirstName() + " "
						+ transaction.getCustomer().getLastName());
				System.out.println("Item: " + item.getTitle());
				System.out.println("Due Date: " + transaction.getCheckOutDate().plusDays(item.getDueDays()));
				System.out.println("-------------------------------");
			}
		}
	}

	public void listAuthorPublications() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("List All Author Publications:");
		// Enter Author's Last Name
		System.out.print("Enter Author's Last Name: ");
		String authorLastName = scanner.nextLine().trim();
		// Find author by last name
		Author author = findAuthorsByLastName(authorLastName);
		if (author == null) {
			System.out.println("Author not found.");
			return;
		}
		System.out.println("Author: " + author);
		boolean foundPub = false;
		for (Item item : app.getItems()) {
			System.out.println("Publications:");
			for (Item pub : app.getItems()) {
				if (pub.getAuthor().equals(author)) {
					foundPub = true;
					System.out.println(item);
				}
			}
		}
		if (foundPub == false) {
			System.out.println("No publications found for that author");
		}
	}

	public static void main(String[] args) {
		Test test = new Test();// menuSystem-> Application app->4 arraylist
		test.runMainMenu();
	}

	private void runMainMenu() {
		Scanner option = new Scanner(System.in);
		while (true) {
			System.out.println("Main Menu");
			System.out.println("Choose one of the next bullets: ");
			System.out.println("1-  Add New Item");
			System.out.println("2-  Update Item");
			System.out.println("3-  Delete Existing Item");
			System.out.println("4-  Add new Customer");
			System.out.println("5-  Update Customer");
			System.out.println("6-  Delete Existing Customer");
			System.out.println("7-  Borrow Transaction.");
			System.out.println("8-  Return Transaction.");
			System.out.println("9-  List of Items Not Yet Returned.");
			System.out.println("10-  List All Author Publications.");
			System.out.println("11-  Save and Exit");

			System.out.print("Choose an option (1-11, 11 to exit): ");
			int choice = option.nextInt();
			option.nextLine();

			switch (choice) {
			case 1:
				addNewItem();
				break;

			case 2:
				updateExistingItem();
				break;

			case 3:
				deleteExistingItem();
				break;

			case 4:
				addNewCustomer();
				break;

			case 5:
				updateExistingCustomer();
				break;

			case 6:
				deleteExistingCustomer();
				break;

			case 7:
				borrowTransaction();
				break;

			case 8:
				returnTransaction();
				break;

			case 9:
				listNotYetReturnedItems();
				break;
			case 10:
				listAuthorPublications();
				break;

			case 11:
				saveData("app.dat");
				System.out.println("Exiting the program.");
				System.exit(0);
				option.close();
				break;

			default:
				System.out.println("Invalid option. Please choose a number between 1 and 11.");
			}

		}
	}

}