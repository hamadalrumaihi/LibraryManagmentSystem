# Library Management System

The project represents a library or inventory management system implemented in Java. It includes functionality for managing different types of items such as books, scientific journals, magazines, and newspapers. Additionally, the system supports the management of customer information.

## Key Features

1. **Adding Items:**
   - Methods like `addNewBook()`, `addNewScientificJournal()`, `addNewMagazine()`, and `addNewNewspaper()` enable users to input details for each type of item and add them to the inventory.

2. **Updating and Deleting Items:**
   - The `updateExistingItem()` method allows users to update details of an existing item based on its title.
   - The `deleteExistingItem()` method enables users to remove an item from the inventory by specifying its title.

3. **Managing Customers:**
   - Methods like `addNewCustomer()`, `updateExistingCustomer()`, and `deleteExistingCustomer()` provide functionality for adding, updating, and deleting customer information.


## Issues / Challenges

1. **Issue 1: File Saving in Object File**
   - **Description:** Initially faced challenges in saving data to an object file.
   - **Resolution:** Overcame by adjusting the file format to save as a `.dat` file and loading it in every run while saving after each operation.

2. **Issue 2: Communication Delays with Team Member Nasser**
   - **Description:** Encountered delays in communication with team member Nasser, impacting collaboration.
   - **Resolution:** Overcame by re-evaluating the project distribution and strategically leaving the last methods for Nasser.

3. **Challenge : Communication with Nasser**
   - **Description:** Communication challenges with Nasser.
   - **Overcame by:** Despite the challenge, successfully solved every issue either individually or in group calls between Hamad and Faisal.

## Tests
 
### Requirement 1
 
![Test 1](C:\Users\pc\OneDrive\Pictures\Screenshots\test-1.png)
 
The "Add New Item" functionality for all item types (Book, Scientific Journal, Magazine, and Newspaper) has been tested and works as expected. The system successfully processes valid inputs for each item type without errors, and error handling is in place for invalid inputs. The user is prompted to enter correct information in case of errors. The overall functionality of adding new items to the library management system is functioning properly.

### Requirement 2
 
![Test 2](C:\Users\pc\OneDrive\Pictures\Screenshots\test-2.png)
![Test 2.1](C:\Users\pc\OneDrive\Pictures\Screenshots\test-2.1png.png)
 
 
all methods are working properly 


### Requirement 3
 
![Test 2](C:\Users\pc\OneDrive\Pictures\Screenshots\test-3.png)
all methods  are working properly 

and the rest are working too


# Project Development Overview

The development of the library management system project was carried out in three stages, with collaborative efforts from a team. The breakdown of responsibilities and communication methods played a crucial role in the project's success.

## Development Stages

### 1. Class Definition and Workload Distribution
   - **Responsibility: Hamad**
   - Hamad took the lead in writing the initial classes and distributing the workload among the team members. This stage laid the foundation for the project structure and defined the entities such as `Book`, `ScientificJournals`, `Magazines`, `NewsPaper`, `Author`, and `Customer`.

### 2. Method Implementation - Collaboration with Faisal
   - **Responsibility: Hamad and Faisal**
   - Hamad and Faisal collaborated in implementing half of the methods for the project. This stage involved writing methods such as `addNewBook()`, `addNewScientificJournal()`, `addNewMagazine()`, `addNewNewspaper()`, `updateExistingItem()`, and `deleteExistingItem()`. The collaboration ensured a balanced and efficient development process.

### 3. Method Implementation - Completion by Nasser
   - **Responsibility: Nasser**
   - Nasser took on the responsibility of completing the remaining methods in the project. This stage included implementing methods such as `deleteExistingCustomer()`, `borrowTransaction()`,`returnTransaction()`,  `listNotYetReturnedItems()` , and `listAuthorPublications()` .Nasser's contribution was supposed to bring the project to its final form yet his work had to be redone by **hamad**.

## Communication and Collaboration

Effective communication and collaboration were key to the success of the project. The team utilized the following methods:

- **GitHub for Version Control:**
  - The team leveraged GitHub to manage version control efficiently. This allowed seamless sharing of the latest project version without the need to save archive files, facilitating collaborative development.

- **Text Messaging:**
  - Text messaging was employed as an immediate communication method to inform team members about the latest project updates, changes, and discussions. It provided a quick and direct means of communication.

## Error Handling

- **Responsibility: Hamad**
  - Hamad, being the initial class and tester class author, took charge of handling errors. This included debugging, fixing issues, and ensuring the overall stability and correctness of the codebase. Hamad's involvement in error resolution contributed to the project's reliability.

The combination of effective communication, collaborative development, and meticulous error handling resulted in the successful completion of the library management system project.
